import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { EisenhowerView } from './components/EisenhowerView';
import { CalendarView } from './components/CalendarView';
import { DirectoryView } from './components/DirectoryView';
import { NotificationsView } from './components/NotificationsView';
import { CoabLogo } from './components/CoabLogo';
import { ShieldCheck, Sparkles, ArrowRight, Lock } from 'lucide-react';

const MainContent: React.FC = () => {
  const { currentTab } = useApp();

  return (
    <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-4 sm:pt-8 pb-24 md:pb-12 transition-all">
      {currentTab === 'dashboard' && <DashboardView />}
      {currentTab === 'eisenhower' && <EisenhowerView />}
      {currentTab === 'calendar' && <CalendarView />}
      {currentTab === 'directory' && <DirectoryView />}
      {currentTab === 'notifications' && <NotificationsView />}
    </main>
  );
};

const AppLayout: React.FC = () => {
  const { 
    currentUser, 
    isLoadingAuth, 
    handleSignIn, 
    signInWithDemoAdmin, 
    isDark 
  } = useApp();

  return (
    <div className={`${isDark ? 'dark' : ''} min-h-screen bg-[#F8FAF9] dark:bg-[#061722] text-[#092638] dark:text-[#F8FAF9] flex flex-col font-sans transition-colors selection:bg-[#E1910F]/30 selection:text-[#092638] relative`}>
      
      {/* Real Website Content - Blurred when unauthenticated */}
      <div className={`flex flex-col min-h-screen transition-all duration-300 ${
        !currentUser && !isLoadingAuth ? 'filter blur-md pointer-events-none select-none opacity-35 dark:opacity-25' : ''
      }`}>
        <Navbar />
        <div className="flex-1">
          <MainContent />
        </div>
        
        {/* Apple-style minimalist footer */}
        <footer className="border-t border-[#064420]/10 dark:border-slate-800/80 py-6 text-center text-xs text-slate-400 dark:text-slate-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>
              College of Accountancy & Business (COAB) Multimedia Committee
            </p>
            <p className="flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Google Account, Calendar, GMail & Drive Synchronized
            </p>
          </div>
        </footer>
      </div>

      {/* Unauthenticated Security Gate Modal */}
      {!currentUser && !isLoadingAuth && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/30 backdrop-blur-md">
          <div className="w-full max-w-md bg-white dark:bg-[#0b2434] rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-2xl p-8 text-center animate-in fade-in zoom-in-95 duration-200">
            
            {/* Seal Logo */}
            <div className="flex justify-center mb-5">
              <div className="relative">
                <CoabLogo size={76} />
                <div className="absolute -bottom-1 -right-1 p-1.5 bg-[#064420] text-white rounded-full shadow-md border-2 border-white dark:border-[#0b2434]">
                  <Lock className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Title & Description */}
            <h2 className="text-xl font-bold tracking-tight text-[#092638] dark:text-white">
              COAB Media Tracker
            </h2>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#064420] dark:text-[#4ade80] mt-1">
              College of Accountancy & Business
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 leading-relaxed">
              Sign in with your authorized Google Account to access production events, 
              the Eisenhower prioritization matrix, and synchronized Google Drive deliverables.
            </p>

            {/* Sign in with Google Primary Button */}
            <div className="mt-6 space-y-3">
              <button
                onClick={handleSignIn}
                className="w-full flex items-center justify-center space-x-3 py-3 px-4 rounded-2xl bg-[#064420] hover:bg-[#05371a] text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all"
              >
                <svg className="w-4 h-4 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              {/* Authorized Account Quick Access */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <p className="text-[10px] uppercase font-bold text-slate-400 mb-2">
                  Authorized Administrator Quick Access
                </p>
                <button
                  onClick={signInWithDemoAdmin}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#061722] hover:bg-slate-100 dark:hover:bg-[#12364c] transition-all text-left"
                >
                  <div className="flex items-center space-x-2.5">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                      alt="Justin Makabenta"
                      className="w-7 h-7 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="text-xs font-bold text-[#092638] dark:text-white flex items-center gap-1">
                        <span>Justin Makabenta</span>
                        <ShieldCheck className="w-3.5 h-3.5 text-[#E1910F]" />
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        makabentajustin55@gmail.com
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-[#E1910F]/15 text-[#E1910F]">
                    Super Admin
                  </span>
                </button>
              </div>
            </div>

            {/* Footnote */}
            <p className="text-[10px] text-slate-400 mt-5">
              Secure authentication powered by Google Workspace OAuth & Firebase
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppLayout />
    </AppProvider>
  );
}
