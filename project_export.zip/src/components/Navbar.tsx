import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CoabLogo } from './CoabLogo';
import { 
  LayoutDashboard, 
  Layers,
  CalendarDays, 
  Users, 
  Bell, 
  Sun, 
  Moon, 
  ShieldCheck, 
  LogOut, 
  CheckCircle2, 
  Sparkles,
  ExternalLink,
  ChevronDown
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    currentTab, 
    setCurrentTab, 
    isDark, 
    toggleTheme, 
    currentUser, 
    currentProfile, 
    userRole, 
    isSuperAdmin,
    handleSignIn, 
    handleSignOut,
    notifications,
    updateMemberRole
  } = useApp();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const roleBadgeColor = {
    admin: 'bg-[#E1910F]/15 text-[#E1910F] border-[#E1910F]/30',
    editor: 'bg-[#245439]/15 text-[#245439] dark:text-[#6ee7b7] border-[#245439]/30',
    contributor: 'bg-[#092638]/10 dark:bg-[#FFFFFF]/10 text-[#092638] dark:text-[#E2E8F0] border-slate-300 dark:border-slate-700',
  };

  return (
    <>
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/90 dark:bg-[#061722]/90 border-b border-[#064420]/10 dark:border-slate-800/80 transition-colors">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between">
          
          {/* Brand & Seal Logo */}
          <div className="flex items-center space-x-2.5 sm:space-x-3 cursor-pointer shrink-0" onClick={() => setCurrentTab('dashboard')}>
            <CoabLogo size={38} />
            <div className="flex flex-col">
              <div className="flex items-center space-x-1.5 sm:space-x-2">
                <span className="font-bold text-base sm:text-lg tracking-tight text-[#092638] dark:text-white flex items-center gap-1">
                  COAB <span className="text-[#064420] dark:text-[#4ade80]">Tracker</span>
                </span>
              </div>
              <span className="hidden sm:block text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                College of Accountancy & Business
              </span>
            </div>
          </div>

          {/* 5 Main Tabs Navigation (Responsive for tablet & desktop) */}
          <nav className="hidden md:flex items-center p-1 bg-slate-100/80 dark:bg-[#0b2434] rounded-2xl border border-slate-200/60 dark:border-slate-700/60 shrink-0">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className={`flex items-center space-x-1.5 lg:space-x-2 px-2.5 lg:px-3.5 py-1.5 lg:py-2 rounded-xl text-[11px] lg:text-xs font-semibold tracking-wide transition-all ${
                currentTab === 'dashboard'
                  ? 'bg-white dark:bg-[#064420] text-[#064420] dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-[#092638] dark:hover:text-white'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5 lg:w-4 lg:h-4 shrink-0" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setCurrentTab('eisenhower')}
              className={`flex items-center space-x-1.5 lg:space-x-2 px-2.5 lg:px-3.5 py-1.5 lg:py-2 rounded-xl text-[11px] lg:text-xs font-semibold tracking-wide transition-all ${
                currentTab === 'eisenhower'
                  ? 'bg-white dark:bg-[#064420] text-[#064420] dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-[#092638] dark:hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5 lg:w-4 lg:h-4 shrink-0" />
              <span>Eisenhower</span>
            </button>

            <button
              onClick={() => setCurrentTab('calendar')}
              className={`flex items-center space-x-1.5 lg:space-x-2 px-2.5 lg:px-3.5 py-1.5 lg:py-2 rounded-xl text-[11px] lg:text-xs font-semibold tracking-wide transition-all ${
                currentTab === 'calendar'
                  ? 'bg-white dark:bg-[#064420] text-[#064420] dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-[#092638] dark:hover:text-white'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5 lg:w-4 lg:h-4 shrink-0" />
              <span>Calendar</span>
            </button>

            <button
              onClick={() => setCurrentTab('directory')}
              className={`flex items-center space-x-1.5 lg:space-x-2 px-2.5 lg:px-3.5 py-1.5 lg:py-2 rounded-xl text-[11px] lg:text-xs font-semibold tracking-wide transition-all ${
                currentTab === 'directory'
                  ? 'bg-white dark:bg-[#064420] text-[#064420] dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-[#092638] dark:hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5 lg:w-4 lg:h-4 shrink-0" />
              <span>Directory</span>
            </button>

            <button
              onClick={() => setCurrentTab('notifications')}
              className={`relative flex items-center space-x-1.5 lg:space-x-2 px-2.5 lg:px-3.5 py-1.5 lg:py-2 rounded-xl text-[11px] lg:text-xs font-semibold tracking-wide transition-all ${
                currentTab === 'notifications'
                  ? 'bg-white dark:bg-[#064420] text-[#064420] dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-[#092638] dark:hover:text-white'
              }`}
            >
              <Bell className="w-3.5 h-3.5 lg:w-4 lg:h-4 shrink-0" />
              <span>Alerts</span>
              {unreadCount > 0 && (
                <span className="flex items-center justify-center min-w-[16px] h-[16px] lg:min-w-[18px] lg:h-[18px] px-1 rounded-full bg-[#E1910F] text-white text-[9px] lg:text-[10px] font-bold">
                  {unreadCount}
                </span>
              )}
            </button>
          </nav>

          {/* Right Action Icons & User Account */}
          <div className="flex items-center space-x-1.5 sm:space-x-3">
            {/* Light / Dark Mode Toggle */}
            <button
              onClick={toggleTheme}
              aria-label="Toggle Theme"
              className="p-2 rounded-xl text-slate-500 hover:text-[#092638] dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors"
            >
              {isDark ? <Sun className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-[#E1910F]" /> : <Moon className="w-4 h-4 sm:w-4.5 sm:h-4.5" />}
            </button>

            {/* Quick Notification icon button on mobile */}
            <button
              onClick={() => setCurrentTab('notifications')}
              className="md:hidden relative p-2 rounded-xl text-slate-500 hover:text-[#092638] dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#E1910F]" />
              )}
            </button>

            {/* Google Account Profile or Sign In Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                  className="flex items-center space-x-2 pl-1.5 sm:pl-2 pr-2 sm:pr-3 py-1 sm:py-1.5 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0b2434] hover:border-[#064420]/30 transition-all shadow-xs"
                >
                  {currentProfile?.photoUrl ? (
                    <img
                      src={currentProfile.photoUrl}
                      alt={currentProfile.name}
                      className="w-6 h-6 sm:w-7 sm:h-7 rounded-full object-cover border border-[#064420]/20"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-[#064420] text-white flex items-center justify-center text-xs font-bold">
                      {currentProfile?.name?.charAt(0) || 'U'}
                    </div>
                  )}
                  <div className="hidden sm:flex flex-col text-left">
                    <span className="text-xs font-semibold text-[#092638] dark:text-white max-w-[100px] lg:max-w-[120px] truncate">
                      {currentProfile?.name || currentUser.displayName}
                    </span>
                    <span className="text-[10px] text-slate-400 capitalize flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {userRole}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Profile Dropdown Popover */}
                {isProfileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-72 max-w-[calc(100vw-24px)] bg-white dark:bg-[#0b2434] border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xl py-3 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-4 pb-3 border-b border-slate-100 dark:border-slate-700/60">
                      <p className="text-xs font-semibold text-[#092638] dark:text-white truncate">
                        {currentProfile?.name}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">{currentUser.email}</p>
                      <div className="mt-2 flex items-center gap-1.5">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${roleBadgeColor[userRole]}`}>
                          {userRole} Access
                        </span>
                        {currentProfile?.org && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {currentProfile.org}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* System Role Management - Restricted to makabentajustin55@gmail.com */}
                    <div className="px-4 py-2.5 bg-slate-50 dark:bg-[#061722]/50 border-b border-slate-100 dark:border-slate-700/60">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-1.5 flex items-center justify-between">
                        <span>System Role Control</span>
                        <ShieldCheck className="w-3 h-3 text-[#E1910F]" />
                      </p>
                      {isSuperAdmin ? (
                        <>
                          <div className="grid grid-cols-3 gap-1">
                            {(['admin', 'editor', 'contributor'] as const).map((r) => (
                              <button
                                key={r}
                                onClick={() => {
                                  if (currentProfile) updateMemberRole(currentProfile.id, r);
                                }}
                                className={`text-[10px] font-semibold py-1 rounded-md transition-all ${
                                  userRole === r
                                    ? 'bg-[#064420] text-white shadow-xs'
                                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                                }`}
                              >
                                {r}
                              </button>
                            ))}
                          </div>
                          <p className="text-[9px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
                            Super Administrator privileges active
                          </p>
                        </>
                      ) : (
                        <div className="py-1">
                          <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md border ${roleBadgeColor[userRole]}`}>
                            Role: {userRole.toUpperCase()}
                          </span>
                          <p className="text-[9px] text-slate-400 mt-1 italic">
                            System roles can only be granted by makabentajustin55@gmail.com
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="px-2 pt-2">
                      <button
                        onClick={() => {
                          setCurrentTab('directory');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between"
                      >
                        <span>Edit My COAB Profile</span>
                        <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                      </button>

                      <button
                        onClick={() => {
                          handleSignOut();
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 flex items-center justify-between"
                      >
                        <span>Sign Out</span>
                        <LogOut className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={handleSignIn}
                className="flex items-center space-x-1.5 sm:space-x-2 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0b2434] hover:bg-slate-50 dark:hover:bg-[#12364c] shadow-xs text-xs font-semibold text-[#092638] dark:text-white transition-all"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span className="hidden sm:inline">Sign in with Google</span>
                <span className="sm:hidden">Sign In</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Floating Modern Mobile Bottom Navigation Dock */}
      <nav 
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#061722]/95 backdrop-blur-xl border-t border-slate-200/80 dark:border-slate-800 px-2 py-1.5 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_20px_rgba(0,0,0,0.3)]"
      >
        <div className="flex items-center justify-around max-w-lg mx-auto">
          <button
            onClick={() => setCurrentTab('dashboard')}
            className={`flex flex-col items-center justify-center min-w-[54px] py-1 px-1 rounded-xl transition-all ${
              currentTab === 'dashboard' 
                ? 'text-[#064420] dark:text-[#4ade80] font-bold bg-[#064420]/10 dark:bg-[#4ade80]/15' 
                : 'text-slate-500 dark:text-slate-400 hover:text-[#092638]'
            }`}
          >
            <LayoutDashboard className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight leading-none">Dashboard</span>
          </button>

          <button
            onClick={() => setCurrentTab('eisenhower')}
            className={`flex flex-col items-center justify-center min-w-[54px] py-1 px-1 rounded-xl transition-all ${
              currentTab === 'eisenhower' 
                ? 'text-[#064420] dark:text-[#4ade80] font-bold bg-[#064420]/10 dark:bg-[#4ade80]/15' 
                : 'text-slate-500 dark:text-slate-400 hover:text-[#092638]'
            }`}
          >
            <Layers className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight leading-none">Matrix</span>
          </button>

          <button
            onClick={() => setCurrentTab('calendar')}
            className={`flex flex-col items-center justify-center min-w-[54px] py-1 px-1 rounded-xl transition-all ${
              currentTab === 'calendar' 
                ? 'text-[#064420] dark:text-[#4ade80] font-bold bg-[#064420]/10 dark:bg-[#4ade80]/15' 
                : 'text-slate-500 dark:text-slate-400 hover:text-[#092638]'
            }`}
          >
            <CalendarDays className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight leading-none">Calendar</span>
          </button>

          <button
            onClick={() => setCurrentTab('directory')}
            className={`flex flex-col items-center justify-center min-w-[54px] py-1 px-1 rounded-xl transition-all ${
              currentTab === 'directory' 
                ? 'text-[#064420] dark:text-[#4ade80] font-bold bg-[#064420]/10 dark:bg-[#4ade80]/15' 
                : 'text-slate-500 dark:text-slate-400 hover:text-[#092638]'
            }`}
          >
            <Users className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight leading-none">Directory</span>
          </button>

          <button
            onClick={() => setCurrentTab('notifications')}
            className={`flex flex-col items-center justify-center min-w-[54px] py-1 px-1 rounded-xl relative transition-all ${
              currentTab === 'notifications' 
                ? 'text-[#064420] dark:text-[#4ade80] font-bold bg-[#064420]/10 dark:bg-[#4ade80]/15' 
                : 'text-slate-500 dark:text-slate-400 hover:text-[#092638]'
            }`}
          >
            <div className="relative">
              <Bell className="w-5 h-5 mb-0.5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1.5 flex items-center justify-center min-w-[14px] h-[14px] px-0.5 rounded-full bg-[#E1910F] text-white text-[8px] font-bold">
                  {unreadCount}
                </span>
              )}
            </div>
            <span className="text-[10px] tracking-tight leading-none">Alerts</span>
          </button>
        </div>
      </nav>
    </>
  );
};
